CHANGELOG
=============

Este arquivo refere-se às mudanças realizadas desde a versão inicial de desenvolvimento.

* 0.1.0 - 07/10/2014
  * Message - Estágio inicial de desenvolvimento