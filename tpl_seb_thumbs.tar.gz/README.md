Thumbnails - tpl_seb_thumbnails
=============

Template para exibição de lista de thumbnails.

Requirements
------------

* [Joomla! 3.0+](http://www.joomla.org)

Author
------

[Rene Bentes Pinto](http://github.com/renebentes)

License
--------

* This Template licensed under the terms of the [GNU/GPLv2](http://www.gnu.org/licenses/gpl-2.0.html) license.

Bugs/Requests
-------------

You can [report a bug or request a feature here](http://github.com/renebentes/tpl_seb_thumbnails/issues)

TODO
----



Release Notes
-------------

You can [see the release notes here](http://github.com/renebentes/tpl_seb_thumbnails/blob/master/CHANGELOG.md)